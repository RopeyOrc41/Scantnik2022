#include <Sensors_Libraries/Adafruit_BME280.h>

volatile float Temp_BME; // Value for the temperature
volatile float Pres_BME; // Value for the pressure
volatile float Hum_BME; // Value for the humidity
volatile float Alt_BME; // Value for the altitude

Adafruit_BME280 bme;

void Setup_BME(){ // Setup of the BME sensor

    bme.begin(); // Initialize sensor

    if (!bme.begin()) { // Give an error if the sensor is not connected
        Serial.println(F("BME sensor not found, check wiring"));
    }

    else{
        Serial.println("BME initialized correctly"); // Print in serial if everything is ok
    }
}

void Loop_BME(){ // The code for the string of the BME

    Pres_BME = bme.readPressure(); // Read pressure
    Temp_BME = bme.readTemperature(); // Read temperature
    Hum_BME = bme.readHumidity(); // Read humidity
    Alt_BME = bme.readAltitude(1013.25); // Calculate altitude

    data1[2] = Temp_BME; // Save temperature readings at the data
    data1[5] = Pres_BME; // Save pressure readings at the data
    data1[7] = Hum_BME; // Save humidity readings at the data
    data2[1] = Alt_BME; // Save altitude readings at the data

    //delay(10);

}