#include <Sensors_Libraries/dht_nonblocking.h>

float Temp_DHT;
float Hum_DHT;

DHT_nonblocking dht_sensor (5, DHT_TYPE_11);

static bool measure_environment( float *Temp_DHT, float *Hum_DHT ){
    
static unsigned long measurement_timestamp = millis( );

/* Measure once every four seconds. */
if( millis( ) - measurement_timestamp > 4000ul )
{
    if( dht_sensor.measure( Temp_DHT, Hum_DHT ) == true )
    {
    measurement_timestamp = millis( );
    return( true );
    }
}

return( false );
}

void Loop_DHT(){

  if( measure_environment( &Temp_DHT, &Hum_DHT ) == true ){
    
    //data1[3] = Temp_DHT;
    //data1[6] = Hum_DHT;

  }
}