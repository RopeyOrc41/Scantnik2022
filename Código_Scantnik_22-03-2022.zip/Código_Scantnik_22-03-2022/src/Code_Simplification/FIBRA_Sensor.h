volatile float fibra1 = 0;
volatile float fibra2 = 0;
volatile float fibra_time = 0;

void Setup_Fibra(){

}

void Loop_Fibra(){

    fibra_time = millis();

    fibra1 = analogRead(14);
    fibra2 = analogRead(15);

    data4[5] = fibra1;
    data4[6] = fibra2;
    data4[7] = fibra_time;
}