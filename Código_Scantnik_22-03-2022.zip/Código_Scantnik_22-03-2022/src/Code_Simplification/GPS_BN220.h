/*#include <Sensors_Libraries/TinyGPS++.h>

//Name the GPS
TinyGPSPlus gps; // Create the GPS object

void Setup_GPS()
{
  Serial1.begin(115200); //Set the baudrate at the serial port of the GPS
}

void Loop_GPS()
{

    while (Serial1.available()){
      gps.encode(Serial1.read());

    //Get latitude, longitude, altitude, satellites and hdop && write the data
    
    data3[1] = gps.satellites.value();

    data3[2] = gps.hdop.hdop();

    data3[3] = gps.location.lat();

    data3[4] = gps.location.lng();

    data3[5] = gps.altitude.meters();

    delay(100);

    if (millis() > 5000 && gps.charsProcessed() < 10)
      Serial.println(F("No GPS data received: check wiring"));
    }
}
*/