#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <Wire.h>

Adafruit_MPU6050 mpu; // Create the MPU object

void Setup_MPU() { // Setup of the MPU

  // Try to initialize!
  if (!mpu.begin()) {
    Serial.println("Failed to find MPU6050 chip"); //Send an error if the connections are not ok
  }

  mpu.setAccelerometerRange(MPU6050_RANGE_8_G); // Set accelerometer range

  switch (mpu.getAccelerometerRange()) {   

  case MPU6050_RANGE_2_G:
    break;
  case MPU6050_RANGE_4_G:
    break;
  case MPU6050_RANGE_8_G:
    break;
  case MPU6050_RANGE_16_G:
    break;
  }

  mpu.setGyroRange(MPU6050_RANGE_500_DEG); // Set gyros range

  switch (mpu.getGyroRange()) {

  case MPU6050_RANGE_250_DEG:
    break;
  case MPU6050_RANGE_500_DEG:
    break;
  case MPU6050_RANGE_1000_DEG:
    break;
  case MPU6050_RANGE_2000_DEG:
    break;
  }

  mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);  // Set filter bandwidth to

  switch (mpu.getFilterBandwidth()) {

  case MPU6050_BAND_260_HZ:
    break;
  case MPU6050_BAND_184_HZ:
    break;
  case MPU6050_BAND_94_HZ:
    break;
  case MPU6050_BAND_44_HZ:
    break;
  case MPU6050_BAND_21_HZ:
    break;
  case MPU6050_BAND_10_HZ:
    break;
  case MPU6050_BAND_5_HZ:
    break;
  }

  delay(100);
}

void Loop_MPU() {

  /* Get new sensor events with the readings */
  sensors_event_t a, g, temp;
  mpu.getEvent(&a, &g, &temp);

    data1[3] = temp.temperature;  // Save temperature readings at the data

    // Save gyroscope readings at the data
    data2[2] = g.gyro.x;
    data2[3] = g.gyro.y; 
    data2[4] = g.gyro.z; 

    // Save acceleration readings at the data
    data2[5] = a.acceleration.x;
    data2[6] = a.acceleration.y; 
    data2[7] = a.acceleration.z; 

  delay(50);
}