#include <nRF24L01.h>
#include <RF24.h>
#include <RF24_config.h>

RF24 radio(9, 5); //Set the pins

const uint64_t pipe = 0xB3B4B5B605LL; //Set the address

volatile float cont = 0; // Create a variable for the id

//Open the comunication
void Setup_NRF24(){

  radio.begin(); // Initialize the radio 
  radio.openWritingPipe(pipe); // Open the radio to start sending the data
}

//Send the data by the antenna
void Loop_NRF24(){

  //radio.openWritingPipe(pipe);
  // Give to each data block an identificator
  
  data1[0] = cont;
  cont++;
  data2[0] = cont;
  cont++;
  data3[0] = cont;
  cont++;
  data4[0] = cont;
  cont++; 

    // Send each data by the NRF24
    radio.write(data1, sizeof data1);
    //delay(5);
    radio.write(data2, sizeof data2);
    //delay(5);
    radio.write(data3, sizeof data3);
    //delay(5);
    radio.write(data4, sizeof data4);
    //delay(5);
  
  //radio.closeWritingPipe(pipe);
}