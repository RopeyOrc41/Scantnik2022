//Print the data in the Serial port
void Print_Data(){
    Serial.println("Id_1, Time, Temp_Bmp, Temp_MPU, Temp_Teensy, Pres_Bmp, Hum_Dht, Hum_BME, Id_2 Alt_BME, Acel_x, Acel_y, Acel_z, Gyro_x, Gyro_y, Gyro_z, Id_3, Sats, HDOP, Lat, Long, Alt_GPS, estos diferente orden Freq, Noise, Signal");
    
    //Print the first packet
    for(int x = 0; x < 7; x++){
        Serial.print(data1[x]);
        Serial.print(" ");
    }

        Serial.print(" ");
        Serial.print(" ");

    //Print the second packet
    for(int x = 0; x < 7; x++){
        Serial.print(data2[x]);
        Serial.print(" ");
    }

        Serial.print(" ");
        Serial.print(" ");

    //Print the third packet
    for(int x = 0; x < 7; x++){
        Serial.print(data3[x]);
        Serial.print(" ");
        }

        Serial.print(" ");
        Serial.print(" ");

    //Print the last packet
    for(int x = 0; x < 7; x++){
        Serial.print(data4[x]);
        Serial.print(" ");
    }

    Serial.println();
    delay(100);
}