#include <SD.h>
#include <SPI.h>

const int chipSelect = 10;

//volatile float cont = 0; // Create a variable for the id

void Setup_SD()
{
  Serial.print("Initializing SD card...");

  if (!SD.begin(chipSelect)) {
    Serial.println("Card failed, or not present");
  }
  // Serial.println("card initialized.");
}

void Loop_SD()
{
/*
  data1[0] = cont;
  cont++;
  data2[0] = cont;
  cont++;
  data3[0] = cont;
  cont++;
  data4[0] = cont;
  cont++;*/
  // open the file
  File dataFile = SD.open("datalog.txt", FILE_WRITE);

  if (dataFile) {
/*
    for(int x = 0; x < 7; x++){
        dataFile.print(data1[x]);
        dataFile.print(" ");
    }
        dataFile.print(" ");
        dataFile.print(" ");

    for(int x = 0; x < 7; x++){
        dataFile.print(data2[x]);
        dataFile.print(" ");
    }
        dataFile.print(" ");
        dataFile.print(" ");

    for(int x = 0; x < 7; x++){
        dataFile.print(data3[x]);
        dataFile.print(" ");
    }
        dataFile.print(" ");
        dataFile.print(" ");

    for(int x = 0; x < 7; x++){
        dataFile.print(data4[x]);
        dataFile.print(" ");
    }
        dataFile.print(" ");
        dataFile.print(" ");

    dataFile.println();
    dataFile.close();

  } else {
    Serial.println("error opening datalog.txt");
  }
  delay(1000);*/

  String dataString = data1[0];
  dataString += (", ");

  dataString += String(data1[1]);
  dataString += (", ");

  dataString += String(data1[2]);
  dataString += (", ");

  dataString += String(data1[3]);
  dataString += (", ");

  dataString += String(data1[4]);
  dataString += (", ");

  dataString += String(data1[5]);
  dataString += (", ");

  dataString += String(data1[6]);
  dataString += (", ");

  dataString += String(data1[7]);
  dataString += (", ");

  dataString += String(data2[0]);
  dataString += (", ");

  dataString += String(data2[1]);
  dataString += (", ");

  dataString += String(data2[2]);
  dataString += (", ");

  dataString += String(data2[3]);
  dataString += (", ");

  dataString += String(data2[4]);
  dataString += (", ");

  dataString += String(data2[5]);
  dataString += (", ");

  dataString += String(data2[6]);
  dataString += (", ");

  dataString += String(data2[7]);
  dataString += (", ");

  dataString += String(data3[0]);
  dataString += (", ");

  dataString += String(data3[1]);
  dataString += (", ");

  dataString += String(data3[2]);
  dataString += (", ");

  dataString += String(data3[3]);
  dataString += (", ");

  dataString += String(data3[4]);
  dataString += (", ");

  dataString += String(data3[5]);
  dataString += (", ");

  dataString += String(data3[6]);
  dataString += (", ");

  dataString += String(data3[7]);
  dataString += (", ");

  dataString += String(data4[0]);
  dataString += (", ");

  dataString += String(data4[1]);
  dataString += (", ");

  dataString += String(data4[2]);
  dataString += (", ");

  dataString += String(data4[3]);
  dataString += (", ");

  dataString += String(data4[4]);
  dataString += (", ");

  dataString += String(data4[5]);
  dataString += (", ");

  dataString += String(data4[6]);
  dataString += (", ");

  dataString += String(data4[7]);
  dataString += (", ");


  dataFile.println(dataString);
  
  delay(40);

  dataFile.close();

  
} else {
  Serial.println("No escribe ");
}

}
