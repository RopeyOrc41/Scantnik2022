#include <Sensors_Libraries/InternalTemperature.h>

volatile float Temp_Teensy; //Set a variable for the temperature of the Teensy

void Loop_Temp_Teensy(){

    Temp_Teensy = InternalTemperature.readTemperatureC(); //Get the temperature

    data1[4] = Temp_Teensy; //Write data

}