volatile float Time;  // Set the variables of time

void Loop_Time_Ide(){

  Time = millis()/1000; //Get the time

  data1[1] = Time; // Save millis in data
}