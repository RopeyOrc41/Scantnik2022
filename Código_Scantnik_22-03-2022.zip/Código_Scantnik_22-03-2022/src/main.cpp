#include <TeensyThreads.h>

 float data1[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 1
 float data2[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 2
 float data3[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 3
 float data4[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 4

#include <Code_Simplification/FFT.h> //Code of the microphone and the FFT
#include <Code_Simplification/BME_Sensor.h> //Code of the BME280 sensor
#include <Code_Simplification/Time_Ide.h> //Code of the time and the identificator
#include <Code_Simplification/DHT_Sensor.h> //Code of the DHT sensor
#include <Code_Simplification/Teensy_Temperature.h> //Code of the internal temperature of the Teensy Board
#include <Code_Simplification/MPU_Sensor.h> //Code of the MPU6050 sensor
#include <Code_Simplification/GPS_BN220.h> //Code of the GPS
#include <Code_Simplification/GPS_BN220_2.h> //Code of the GPS
#include <Code_Simplification/Print.h> //Code to print all the data
#include <Code_Simplification/NRF24.h> //Code to send the data by radio
#include <Code_Simplification/SD.h>//Code for the datalogger
#include <Code_Simplification/FIBRA_Sensor.h>//

//Send data by radio
void Thread_NRF(){ 

    while (true){

        Loop_SD();
        delay(100);
        Loop_NRF24();
    }

}

//Get location using the BN220
void Thread_GPS(){

    while (true){

        //Loop_SD();
        Loop_GPS_2();
    }
}

//Get data of all other sensors
void Thread_Sensors(){

    while (true){

        Loop_Time_Ide();
        Loop_BME();
        //Loop_DHT();
        Loop_Temp_Teensy();
        Loop_MPU();
        //Print_Data();
        //Loop_Fibra();
        //Loop_SD();
    }
}

void Thread_PrintData(){

    while (true){

        Print_Data();

    }
}

void Thread_SD(){

    while (true){

        Loop_SD();
    }
}

void setup() {

    threads.setMicroTimer(50);
    threads.setSliceMicros(50);
    threads.setDefaultTimeSlice(1);

    Setup_FFT();
    Setup_BME();
    Setup_MPU();
    Setup_GPS_2();
    Setup_NRF24();
    //Setup_Fibra();
    Setup_SD();

    threads.addThread(Thread_Sensors);
    threads.addThread(Thread_GPS);
    //threads.addThread(Thread_NRF);
    threads.addThread(Thread_PrintData);
}

void loop() {

    //Loop_FFT(); //Run the microphone and the FFT
    //Print_Data(); //Print the data in Serial
    Loop_SD();
    Loop_NRF24();
    //Loop_GPS_2();
}

// Code only with SD card
/*
#include <TeensyThreads.h>

 float data1[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 1
 float data2[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 2
 float data3[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 3
 float data4[8] = {0, 0, 0, 0, 0, 0, 0, 0}; //Data storage 4

#include <Code_Simplification/FFT.h> //Code of the microphone and the FFT
#include <Code_Simplification/BME_Sensor.h> //Code of the BME280 sensor
#include <Code_Simplification/Time_Ide.h> //Code of the time and the identificator
#include <Code_Simplification/DHT_Sensor.h> //Code of the DHT sensor
#include <Code_Simplification/Teensy_Temperature.h> //Code of the internal temperature of the Teensy Board
#include <Code_Simplification/MPU_Sensor.h> //Code of the MPU6050 sensor
#include <Code_Simplification/GPS_BN220.h> //Code of the GPS
#include <Code_Simplification/Print.h> //Code to print all the data
#include <Code_Simplification/NRF24.h> //Code to send the data by radio
#include <Code_Simplification/SD.h>//Code for the datalogger
#include <Code_Simplification/FIBRA_Sensor.h>//

//Send data by radio
void Thread_NRF(){ 

    while (true){

        //Loop_SD();
        Loop_NRF24();
        // Important not to put the SD code in the Radio Thread
    }

}

//Get location using the BN220
void Thread_GPS(){

    while (true){

        //Loop_SD();
        Loop_GPS();
    }
}

//Get data of all other sensors
void Thread_Sensors(){

    while (true){

        Loop_Time_Ide();
        Loop_BME();
        Loop_DHT();
        Loop_Temp_Teensy();
        Loop_MPU();
        //Print_Data();
        //Loop_Fibra();
        //Loop_SD();
    }
}

void Thread_PrintData(){

    while (true){

        Print_Data();

    }
}

void Thread_SD(){

    while (true){

        Loop_SD();
    }
}

void setup() {

    threads.setMicroTimer(50);
    threads.setSliceMicros(50);
    threads.setDefaultTimeSlice(1);

    Setup_FFT();
    Setup_BME();
    Setup_MPU();
    Setup_GPS();
    Setup_NRF24();
    //Setup_Fibra();
    Setup_SD();

    threads.addThread(Thread_Sensors);
    threads.addThread(Thread_GPS);
    //threads.addThread(Thread_NRF);
    threads.addThread(Thread_PrintData);
    //threads.addThread(Thread_SD);
}

void loop() {

    Loop_FFT(); //Run the microphone and the FFT
    //Print_Data(); //Print the data in Serial
    Loop_SD();
    //Loop_NRF24();
} */